import { ObjectID } from 'bson';

export class TEdition {
    _id: ObjectID;
    name: string;
}
